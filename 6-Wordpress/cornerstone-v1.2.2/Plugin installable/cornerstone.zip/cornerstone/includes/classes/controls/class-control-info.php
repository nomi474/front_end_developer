<?php
class Cornerstone_Control_Info extends Cornerstone_Control {
	protected $default_options = array(
		'help-text' => true,
		'heading' => '',
		'message' => ''
  );
}